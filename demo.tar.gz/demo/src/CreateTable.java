import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import technology.tabula.ObjectExtractor;
import technology.tabula.Page;
import technology.tabula.PageIterator;
import technology.tabula.RectangularTextContainer;
import technology.tabula.Table;
import technology.tabula.extractors.BasicExtractionAlgorithm;
import technology.tabula.extractors.ExtractionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

public class CreateTable {
    public static void main(String[] args) throws IOException {
        final String FILE_NAME = "src/file/abc.pdf";
        final String FILE_RESULT = "src/result/abc.xlsx";

        PDDocument pd = PDDocument.load(new File(FILE_NAME));

        int totalPages = pd.getNumberOfPages();
        System.out.println("Total Pages in Document: " + totalPages);

        ObjectExtractor oe = new ObjectExtractor(pd);
        ExtractionAlgorithm extractor = new BasicExtractionAlgorithm();
        // SpreadsheetExtractionAlgorithm sea = new SpreadsheetExtractionAlgorithm();
        PageIterator it = oe.extract();

        // extract text from the table after detecting
        XSSFWorkbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Barang Baik");
        while (it.hasNext()) {
            Page page = it.next();
            for (Table table : extractor.extract(page)) {
                List<List<RectangularTextContainer>> rows = table.getRows();
                for (int i = 0; i < rows.size(); i++) {

                    Row rowOut = sheet.createRow(i);
                    List<RectangularTextContainer> cells = rows.get(i);
                    for (int j = 0; j < cells.size(); j++) {
                        
                        rowOut.createCell(j).setCellValue(cells.get(j).getText());
                    }
                }
            }
        }
        FileOutputStream fos = new FileOutputStream(FILE_RESULT);
        wb.write(fos);
        fos.close();

    }
}
